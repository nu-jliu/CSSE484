

// TODO: Create the TicTacToeGame class



/* ----------------- Official Playground testing ----------------- */
//var game = TicTacToeGame()
//game.pressedSquareAt(0)
//game.pressedSquareAt(1)
//game.pressedSquareAt(3)
//game.pressedSquareAt(2)
//game.pressedSquareAt(6)


//var game2 = TicTacToeGame()
//game2.board = [.x, .x, .o,
//                .none, .none, .none,
//                .o, .none, .none]
//game2.pressedSquareAt(8)
//game2.pressedSquareAt(4)


//var game3 = TicTacToeGame()
//game3.board = [.x, .x, .o,
//    .o, .o, .x,
//    .x, .o, .none]
//game3.pressedSquareAt(8)

